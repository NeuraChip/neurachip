// Playground for testing and debugging DRAMSIM3

#include "play.h"
#include <iostream>

using namespace std;

int main()
{
	cout << "Hello World!\n";
}